// Connect to the Socket.IO server
const socket = io('http://localhost:3000'); // Replace with your backend URL if hosted

// Get references to HTML elements
const chatBox = document.getElementById('chat-box');
const messageInput = document.getElementById('message-input');
const sendButton = document.getElementById('send-button');

// Function to add a new message to the chat box
function addMessage(message) {
    const messageElement = document.createElement('div');
    messageElement.classList.add('message');
    messageElement.textContent = message;
    chatBox.appendChild(messageElement);
}

// Send a message to the server
sendButton.addEventListener('click', () => {
    const message = messageInput.value.trim();
    if (message) {
        socket.emit('sendMessage', message); // Emit the message to the server
        messageInput.value = ''; // Clear the input box
    }
});

// Listen for incoming messages from the server
socket.on('receiveMessage', (message) => {
    addMessage(message);
});